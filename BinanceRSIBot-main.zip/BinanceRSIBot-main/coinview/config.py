import os

API_KEY = os.environ['API_KEY_BINANCE']
API_SECRET = os.environ['API_SECRET_BINANCE']